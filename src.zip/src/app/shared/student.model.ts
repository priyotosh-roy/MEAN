export class Student {
    _id:String;
    name:String;
    roll_number:String;
    branch:String;
    mobile:String;

}
