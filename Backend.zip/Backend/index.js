const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const { mongoose }  = require('./db.js')
const StudentController = require('./controllers/StudentController');

const app = express();

app.use(cors({ origin : 'http://localhost:4200'}));

app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json());

app.use('/students',StudentController);

app.listen(5000,()=> console.log('server started at port : 5000'));



