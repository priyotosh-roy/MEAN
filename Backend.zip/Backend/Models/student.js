const mongoose = require('mongoose');

var Student = mongoose.model('Student' , {
    name : {
        type:String,
        required:true
    },
    roll_number :{
        type:String,
        required:true
    },
    branch:{
        type:String,
        required:true
    },
    mobile:{
        type:String
    },
    Date : {
        type : Date,
        default : Date.now
    }
});

module.exports = { Student };